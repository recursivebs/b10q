export enum NoteColor {
    /**
     * Left hand color
     */
    Red = 0,

    /**
     * Right hand color
     */
    Blue = 1,
    Unknown = 999
}
